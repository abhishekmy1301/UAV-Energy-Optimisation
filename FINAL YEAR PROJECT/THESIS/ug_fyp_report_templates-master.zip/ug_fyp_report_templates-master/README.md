# Informatics UG Individual Projects
## LaTeX template for reports

This repository contains a LaTeX class file to be used for creating reports as part of your individual project. In addition to the class file, there is a set of `.tex` files that, together and starting from file `report.tex`, can be used as the starting point when writing your final report.
