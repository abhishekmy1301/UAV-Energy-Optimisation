t = zeros(250,1 );

for n = 5:250
    counter = n
    [~,~,~,~,~,time] = Final(n);
    t(n,1) = time;
end

writematrix(t,'time_complexity,4K,linear_cost.xlsx','Sheet',1)