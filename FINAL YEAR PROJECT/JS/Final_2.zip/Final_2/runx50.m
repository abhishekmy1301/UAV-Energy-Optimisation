function yourLoop
result = zeros(100, 5);
tic
for k = 1:100
    counter = k
    [my_dist,their_dist_sqe,their_dist_cb,their_dist_cos,their_dist_cor,~] = Final(100);
    result(k,1) = my_dist
    result(k,2) = their_dist_sqe
    result(k,3) = their_dist_cb
    result(k,4) = their_dist_cos
    result(k,5) = their_dist_cor
end
t = toc/100
writematrix(result,'100nodes,6K,cubed_cost.xlsx','Sheet',1)
end



